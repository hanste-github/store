user_pref("toolkit.legacyUserProfileCustomizations.stylesheets", true);
user_pref("svg.context-properties.content.enabled", true);
user_pref("layout.css.backdrop-filter.enabled", true);
user_pref("layers.acceleration.force-enabled", true);

user_pref("full-screen-api.macos-native-full-screen", true);
user_pref("full-screen-api.warning.delay", -1);
user_pref("full-screen-api.warning.timeout", 0);

user_pref("browser.newtabpage.activity-stream.showSearch", true);
